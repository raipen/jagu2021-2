#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>

typedef int element;
typedef struct t {
	element data;
	struct t* left, * right;
}tree;

tree* new_tree(int input) {
	tree* temp = (tree*)malloc(sizeof(tree));
	temp->data = input;
	temp->left = temp->right = NULL;
	return temp;
}

void insert_bst(tree** root, int input) {
	if (!(*root)) {
		(*root) = new_tree(input);
		return;
	}
	tree* cur = (*root);
	tree* pre=NULL;
	while (cur) {
		pre = cur;
		cur = cur->data > input ? cur->left : cur->right;
	}
	if (pre->data > input)
		pre->left = new_tree(input);
	else
		pre->right = new_tree(input);
}

void postorder(tree* bst) {
	if (bst) {
		postorder(bst->left);
		postorder(bst->right);
		printf("%d ", bst->data);
	}
}

int maxheight(tree* root) {
	if (!root) return 0;
	return maxheight(root->left)+1> maxheight(root->right) + 1? maxheight(root->left) + 1: maxheight(root->right) + 1;
}

tree* find_node(tree* root, int input) {
	if (!root) return NULL;
	tree* cur = root;
	while (cur) {
		if (cur->data == input) return cur;
		cur = cur->data > input ? cur->left : cur->right;
	}
	return NULL;
}

int node_count(tree* root) {
	if (!root->left&&!root->right) return 1;
	if (!root->left) return 1 + node_count(root->right);
	if (!root->right) return 1 + node_count(root->left);
	return 1 + node_count(root->left) + node_count(root->right);
}

void main() {
	int input;
	FILE* fp = fopen("in3.txt", "r");
	tree* bst = NULL;
	while(!feof(fp)){
		fscanf(fp, "%d", &input);
		insert_bst(&bst, input);
	}

	printf("(1) Postorder traversal:");
	postorder(bst);
	printf("\n(2) Height: %d\n",maxheight(bst));
	printf("(3) Node# of subtree\n");
	tree* newroot;
	do {
		printf("Input key:");
		scanf("%d", &input);
		newroot = find_node(bst, input);
		if (newroot)
			printf("Node#(%d):%d\n", input, node_count(newroot));
	} while(newroot);
	printf("Fail");
}