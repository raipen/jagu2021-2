#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>

typedef struct {
	char name[10];
	int grade;
	int num;
}student;

//��ũ�� ť ���� ����
typedef student element;
typedef struct q {
    element value;
    struct q* link;
}q_node;
typedef struct {
    struct q* front;
    struct q* rear;
}queue;

queue* newQ() {
    queue* que = (queue*)malloc(sizeof(queue));
    que->front = NULL;
    que->rear = NULL;
    return que;
}

void freeQ(queue* this) {
    while (this->front != NULL) {
        q_node* temp = this->front;
        this->front = this->front->link;
        free(temp);
    }
    free(this);
}

int isEmpty(queue* this) {
    return !this->front;
}

void addq(queue* this, element value) {
    q_node* temp = (q_node*)malloc(sizeof(q_node));
    temp->value = value;
    temp->link = NULL;
    if (this->front)
        this->rear->link = temp;
    else
        this->front = temp;
    this->rear = temp;
}

element deleteq(queue* this) {
    q_node* temp = this->front;
    element item = temp->value;
    this->front = temp->link;
    free(temp);
    return item;
}
//��ũ�� ť ���� ��

queue** newQarr(int size) {
    queue** que = (queue**)malloc(sizeof(queue*));
    for (int i = 0; i < size; i++) {
        que[i]= newQ();
    }
    return que;
}

void print_student(student st[],int size) {
	for (int i = 0; i < size; i++) {
		printf("%s %d %d\n", st[i].name, st[i].grade, st[i].num);
	}
}

int return_key(student st, int key) {
	return key ? st.grade : st.num;
}

void radix_sort(student st[], int size) {
    queue** que[2] = { newQarr(11),newQarr(7) };
	for(int key = 0;key<2;key++){
        for (int i = 0; i < size; i++) {
            addq(que[key][return_key(st[i],key)], st[i]);
        }
        int cur = 0;
        for (int i = 0; i < size; i++) {
            while (isEmpty(que[key][cur])) cur++;
            st[i] = deleteq(que[key][cur]);
        }
	}
}

void main() {
	int size;
	FILE* fp = fopen("in2.txt", "r");
	fscanf(fp, "%d", &size);
	student* input = (student*)calloc(size, sizeof(student));
	for (int i = 0; i < size; i++) {
		fscanf(fp, "%s %d %d", input[i].name, &input[i].grade, &input[i].num);
	}
	radix_sort(input, size);
	print_student(input,size);
}