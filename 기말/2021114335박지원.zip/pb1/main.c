#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>

typedef struct {
	int size;
	int** edge;
}adj_matrix;

//��ũ�� ť ���� ����
typedef int element;
typedef struct q {
    element value;
    struct q* link;
}q_node;
typedef struct {
    struct q* front;
    struct q* rear;
}queue;

queue* newQ() {
    queue* que = (queue*)malloc(sizeof(queue));
    que->front = NULL;
    que->rear = NULL;
    return que;
}

void freeQ(queue* this) {
    while (this->front != NULL) {
        q_node* temp = this->front;
        this->front = this->front->link;
        free(temp);
    }
    free(this);
}

int isEmpty(queue* this) {
    return !this->front;
}

void addq(queue* this, element value) {
    q_node* temp = (q_node*)malloc(sizeof(q_node));
    temp->value = value;
    temp->link = NULL;
    if (this->front)
        this->rear->link = temp;
    else
        this->front = temp;
    this->rear = temp;
}

element deleteq(queue* this) {
    q_node* temp = this->front;
    if (!temp)
        return NULL;
    element item = temp->value;
    this->front = temp->link;
    free(temp);
    return item;
}
//��ũ�� ť ���� ��


adj_matrix* new_adj_matrix(int size) {
	adj_matrix* temp = (adj_matrix*)malloc(sizeof(adj_matrix));
	temp->size = size;
	temp->edge = (int**)malloc(sizeof(int*)*size);
	for (int i = 0; i < size; i++) {
		temp->edge[i] = (int*)calloc(size,sizeof(int));
	}
	return temp;
}

void print_Componet(adj_matrix* am) {
	int* isVisited = (int*)calloc(am->size, sizeof(int));
	queue* que = newQ();
    int comp = 1;
	for (int i = 0; i < am->size; i++) {
		if (!isVisited[i]) {
            printf("Component#%d: %2d",comp++, i);
            isVisited[i] = 1;
            addq(que, i);
            while (!isEmpty(que)) {
                int cur = deleteq(que);
                for (int j = 0; j < am->size; j++) {
                    if (am->edge[cur][j] && !isVisited[j]) {
                        addq(que, j);
                        printf("%2d", j);
                        isVisited[j] = 1;
                    }
                }
            }
            printf("\n");
		}
	}

}

void main() {
	int size;
	FILE* fp = fopen("in1.txt", "r");
	fscanf(fp,"%d", &size);
	adj_matrix* input = new_adj_matrix(size);
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			fscanf(fp, "%d", &input->edge[i][j]);
		}
	}
	print_Componet(input);
}