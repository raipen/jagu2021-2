#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define SWAP(x,y,t) t=x;x=y;y=t

typedef struct {
    int key;
    char data[100];
}element;

void printarr(element arr[], int n) {
    for (int i = 0;i < n;i++) {
        printf("%5s:%4d\n", arr[i].data, arr[i].key);
    }
}

int comp(int a, int b) {
    return a < b ? -1 : a == b ? 0 : 1;
}

element* merge(element arr[], int a, int b, int c) {
    if (b >= c) return NULL;
    int i = a, j = b;
    element* temp = (element*)malloc(sizeof(element) * (c - a));
    int index = 0;
    while (i < b && j < c) {
        switch (comp(arr[i].key, arr[j].key)) {
        case -1:
            temp[index++] = arr[i++];
            break;
        case 0: temp[index++] = arr[i++];
        case 1:
            temp[index++] = arr[j++];
            break;
        }
    }
    for (; i < b; temp[index++] = arr[i++]);
    for (; j < c; temp[index++] = arr[j++]);
    return temp;
}

void mergeSort(element arr[], int length) {
    int n = 1;
    while (n < length) {
        for (int i = 0;i < length;i += n * 2) {
            element* temp = merge(arr, i, i + n < length ? i + n : length , i + 2 * n < length ? i + 2 * n : length);
            if (temp)
                for (int j = i;j < (i + 2 * n < length ? i + 2 * n : length);j++)
                    arr[j] = temp[j-i];
            free(temp);
        }
        n = n * 2;
    }
}

void main() {
    FILE* fp = fopen("in.txt", "r");
    int cnt;
    fscanf(fp, "%d", &cnt);
    element* arr = (element*)malloc(sizeof(element) * cnt);
    for (int i = 0;i < cnt;i++) {
        fscanf(fp, "%s %d", arr[i].data, &arr[i].key);
    }
    printf("[after quick sort]\n");
    mergeSort(arr, cnt);
    printarr(arr, cnt);
    free(arr);
}