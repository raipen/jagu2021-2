#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef int contents;
typedef struct n{
	contents value;
	struct n* next;
}node;

void insert(node** head, contents value, int (*fun)()) {
	if (*head == NULL) {
		(*head) = (node*)malloc(sizeof(node));
		(*head)->value = value;
		(*head)->next = NULL;
		return;
	}

	node* temp = (node*)malloc(sizeof(node));
	temp->value = value;
	if (fun()) {
		temp->next = *head;
		(*head) = temp;
		return;
	}
	node* cur = *head;
	while (cur->next != NULL && !fun()) {
		cur = cur->next;
	}
	temp->next = cur->next;
	cur->next = temp;
}

int inFirst() {
	return 1;
}

int inLast() {
	return 0;
}

void printList(node* head) {
	while (head!=NULL) {
		printf("%d ", head->value);
		head = head->next;
	}
	printf("\n");
}

int findMin(node* head) {
	int index=0;
	int min=head->value;
	int minIndex = 0;
	head = head->next;
	index++;
	while (head != NULL) {
		if (min > head->value) {
			min = head->value;
			minIndex = index;
		}
		head = head->next;
		index++;
	}
	return minIndex;
}

void deleteIndex(node** head, int index) {
	if (!index) {
		(*head) = (*head)->next;
	}
	node* cur = (*head);
	for (int i = 0;i < index - 1;i++) {
		cur = cur->next;
	}
	cur->next = cur->next->next;
}

void doFromFile(char* name) {
	printf("[%s]\n", name);
	FILE* fp = fopen(name, "r");
	if (!fp) {
		printf("���� ����\n");
		exit(1);
	}
	node* head = NULL;
	while (!feof(fp)) {
		int temp;
		fscanf(fp, "%d", &temp);
		if (temp < 0) insert(&head, temp, inFirst);
		else insert(&head, temp, inLast);
	}
	printList(head);
	int index = findMin(head);
	deleteIndex(&head, index);
	printf("after deleting MIN...\n");
	printList(head);
}

void main() {
	doFromFile("in21.txt");
	doFromFile("in22.txt");
}