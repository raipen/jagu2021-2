#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef struct {
	int row;
	int col;
	int value;
}matrix;

matrix* add_matrix_from_file(char* name) {
	FILE* fp = fopen(name, "r");
	if (!fp) {
		printf("���� ����\n");
		exit(1);
	}
	matrix set;
	fscanf(fp, "%d %d %d", &set.row, &set.col, &set.value);
	matrix* temp = (matrix*)malloc(sizeof(matrix) * (set.value + 1));
	temp[0] = set;
	for(int i=1;i<=set.value;i++) {
		fscanf(fp, "%d %d %d", &temp[i].row, &temp[i].col, &temp[i].value);
	}
	return temp;
}

int compare(matrix m1, matrix m2) {
	if (m1.row == m2.row) {
		if (m1.col == m2.col)
			return 0;
		return m1.col < m2.col ? -1 : 1;
	}
	return m1.row < m2.row ? -1 : 1;
}

matrix* add_matrix(matrix m1[], matrix m2[]) {
	int m1_index = 1,m2_index = 1;
	matrix* result = (matrix*)malloc(sizeof(matrix) * (m1[0].value+m2[0].value + 1));
	int count = 1;
	while (m1_index <= m1[0].value && m2_index <= m2[0].value) {
		switch (compare(m1[m1_index], m2[m2_index])) {
		case -1:
			result[count] = m1[m1_index];
			count++;
			m1_index++;
			break;
		case 0:
			result[count] = m1[m1_index];
			result[count].value += m2[m2_index].value;
			if (result[count].value)
				count++;
			m1_index++;
			m2_index++;
			break;
		case 1:
			result[count] = m2[m2_index];
			count++;
			m2_index++;
			break;
		}
	}
	while (m1_index <= m1[0].value) {
		result[count] = m1[m1_index];
		count++;
		m1_index++;
	}
	while (m2_index <= m2[0].value) {
		result[count] = m2[m2_index];
		count++;
		m2_index++;
	}
	result[0] = m1[0];
	result[0].value = count - 1;
	return result;
}

void print_matrix(matrix m[]) {
	printf("row col value\n");
	for (int i = 0;i <= m[0].value;i++) {
		printf("%3d %3d %3d\n", m[i].row, m[i].col, m[i].value);
	}
}

void main() {
	matrix* matrix1 = add_matrix_from_file("in31.txt");
	matrix* matrix2 = add_matrix_from_file("in32.txt");
	matrix* matrix_result = add_matrix(matrix1, matrix2);
	print_matrix(matrix_result);
}