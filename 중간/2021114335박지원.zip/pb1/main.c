#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 100

typedef char contents;
contents stack[MAX_SIZE];
int top = -1;

int isEmpty() {
	return top == -1 ? 1 : 0;
}
int isFull() {
	return top == MAX_SIZE - 1 ? 1 : 0;
}

void push(contents v) {
	if (isFull()) {
		printf("���� �� ��\n");
		exit(1);
	}
	stack[++top] = v;
}

contents pop() {
	if (isEmpty()) {
		printf("���� �����\n");
		return 0;
	}
	return stack[top--];
}

int isPal(char str[]) {
	int i = -1;
	while (str[++i] != '\0') {
		push(str[i]);
	}
	i = -1;
	while (str[++i] != '\0') {
		if (str[i] != pop())
			return 0;
	}
	return 1;
}

void main() {
	FILE* fp = fopen("in1.txt", "r");
	if (!fp) {
		printf("���� ����\n");
		exit(1);
	}
	while (!feof(fp)) {
		char str[100];
		fscanf(fp, "%s", str);
		printf("%s is %spalindrome\n", str, isPal(str) ? "" : "NOT ");
	}
	fclose(fp);
}